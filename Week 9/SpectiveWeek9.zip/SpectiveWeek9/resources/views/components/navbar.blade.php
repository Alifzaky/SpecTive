<!-- NAVBAR SECTION -->
<nav class="border-b border-slate-800/80 dark:border-slate-800/80 bg-[#0b0f19]/90 dark:bg-[#0b0f19]/95 bg-white/90 border-slate-200 backdrop-blur-md sticky top-0 z-50 transition-all duration-300">
  <div class="max-w-7xl mx-auto px-4 sm:px-8 h-16 flex items-center justify-between relative z-50">

    <!-- Logo -->
    <a href="#" class="flex items-center space-x-3 group">
      <div class="w-9 h-9 rounded-xl bg-gradient-to-tr from-sky-500 to-blue-600 flex items-center justify-center font-extrabold text-slate-950 shadow-lg shadow-sky-500/20 text-lg transition-transform group-hover:scale-105 duration-300">S</div>
      <span class="font-extrabold text-xl text-slate-900 dark:text-white tracking-wide">SpecTive</span>
    </a>

    <!-- Desktop Menu -->
    <div class="hidden md:flex items-center space-x-2 text-xs text-slate-600 dark:text-slate-300 font-medium h-full">
      <a href="#katalog" class="nav-item relative px-3 h-full flex items-center hover:text-sky-500 dark:hover:text-sky-400 transition-colors">Katalog</a>
      <a href="#edukasi" class="nav-item relative px-3 h-full flex items-center hover:text-sky-500 dark:hover:text-sky-400 transition-colors">Tips & Edukasi</a>
      <a href="#matrix" class="nav-item relative px-3 h-full flex items-center hover:text-sky-500 dark:hover:text-sky-400 transition-colors">Hardware Matrix</a>
      <a href="#lokasi" class="nav-item relative px-3 h-full flex items-center hover:text-sky-500 dark:hover:text-sky-400 transition-colors">Cari Toko</a>
      <a href="#faq" class="nav-item relative px-3 h-full flex items-center hover:text-sky-500 dark:hover:text-sky-400 transition-colors">FAQ</a>
    </div>

    <!-- Action Button, Theme Toggle & Mobile Toggle -->
    <div class="flex items-center gap-3">
      <!-- Tombol Dark/Light Mode Toggle -->
      <button id="theme-toggle" class="w-9 h-9 rounded-lg bg-slate-100 dark:bg-slate-900 border border-slate-300 dark:border-slate-800 flex items-center justify-center text-slate-700 dark:text-sky-400 hover:border-sky-500 transition-colors focus:outline-none" title="Ubah Tema">
        <i id="theme-icon" class="fa-solid fa-moon text-sm"></i>
      </button>

      <a href="#katalog" class="hidden sm:inline-block bg-sky-500 hover:bg-sky-400 text-slate-950 font-bold text-xs px-4 py-2.5 rounded-lg transition-all shadow-md shadow-sky-500/20 active:scale-95">
        Cek Spesifikasi
      </a>

      <!-- Mobile Menu Button -->
      <button id="mobile-menu-btn" class="md:hidden text-slate-700 dark:text-slate-300 hover:text-sky-500 dark:hover:text-sky-400 focus:outline-none transition-colors p-2">
        <i class="fa-solid fa-bars text-xl"></i>
      </button>
    </div>
  </div>

  <!-- Mobile Menu Overlay -->
  <div id="mobile-menu" class="fixed inset-0 bg-white/95 dark:bg-[#0b0f19]/95 backdrop-blur-xl flex flex-col pt-24 px-6 gap-6 transform translate-x-full transition-transform duration-300 ease-in-out md:hidden z-40 h-screen">
    <a href="#katalog" class="mobile-nav-item text-lg font-bold text-slate-800 dark:text-slate-300 hover:text-sky-500 dark:hover:text-sky-400 border-b border-slate-200 dark:border-slate-800 pb-4">Katalog Laptop</a>
    <a href="#edukasi" class="mobile-nav-item text-lg font-bold text-slate-800 dark:text-slate-300 hover:text-sky-500 dark:hover:text-sky-400 border-b border-slate-200 dark:border-slate-800 pb-4">Tips & Edukasi</a>
    <a href="#matrix" class="mobile-nav-item text-lg font-bold text-slate-800 dark:text-slate-300 hover:text-sky-500 dark:hover:text-sky-400 border-b border-slate-200 dark:border-slate-800 pb-4">Hardware Matrix</a>
    <a href="#lokasi" class="mobile-nav-item text-lg font-bold text-slate-800 dark:text-slate-300 hover:text-sky-500 dark:hover:text-sky-400 border-b border-slate-200 dark:border-slate-800 pb-4">Cari Toko Offline</a>
    <a href="#faq" class="mobile-nav-item text-lg font-bold text-slate-800 dark:text-slate-300 hover:text-sky-500 dark:hover:text-sky-400 border-b border-slate-200 dark:border-slate-800 pb-4">Konsultasi FAQ</a>
    <a href="#katalog" class="bg-sky-500 text-center text-slate-950 font-bold px-4 py-3 rounded-xl mt-4 shadow-lg shadow-sky-500/20">Mulai Cek Spesifikasi</a>
  </div>
</nav>
